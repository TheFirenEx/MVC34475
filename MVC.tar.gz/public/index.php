<?php

require __DIR__ . '/../bootstrap/bootstrap.php';
