<?php
namespace Database;

interface HandleInterface 
{
    public function getHandle();
}
