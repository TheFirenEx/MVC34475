<?php 

namespace Models;

class Category extends Model 
{
    protected $attributes = [
        'id' => null,
        'name' => null
    ];
}