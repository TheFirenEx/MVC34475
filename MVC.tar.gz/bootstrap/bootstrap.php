<?php

use Http\Kernel;

require __DIR__ . '/../vendor/autoload.php';

(new Kernel())->run();
