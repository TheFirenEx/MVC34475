docker run --rm \
    -u "$(id -u):$(id -g)" \
    -v $(pwd):/opt \
    -w /opt \
    composer:latest \
    composer install --ignore-platform-reqs

